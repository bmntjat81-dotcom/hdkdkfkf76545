package com.alfnon.platform.data

import android.content.Context
import java.security.MessageDigest

class LocalAuthStore(context: Context) {
    private val prefs = context.getSharedPreferences("alf_non_accounts", Context.MODE_PRIVATE)

    fun authenticate(name: String, code: String, role: UserRole): Boolean {
        val key = normalize(name)
        if (key.length < 2 || code.length < 3) return false
        val existing = prefs.getString("$key:account", null)
        if (existing == null) {
            prefs.edit().putString("$key:account", "${role.name}|${hash(code)}").apply()
            return true
        }
        val parts = existing.split('|')
        return parts.size == 2 && parts[0] == role.name && parts[1] == hash(code)
    }

    private fun normalize(value: String) = value.trim().lowercase().replace(" ", "_")
    private fun hash(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
