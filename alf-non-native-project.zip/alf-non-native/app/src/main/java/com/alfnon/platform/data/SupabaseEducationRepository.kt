package com.alfnon.platform.data

import org.json.JSONArray
import org.json.JSONObject

class SupabaseEducationRepository(private val client: SupabaseRestClient = SupabaseRestClient()) {
    suspend fun classes(token: String): List<ClassRoom> = runCatching {
        val array = JSONArray(client.select("classes", token, "select=id,name,subject&order=created_at.desc").getOrThrow())
        List(array.length()) { val item = array.getJSONObject(it); ClassRoom(item.optString("id").stableId(), item.optString("name"), item.optString("subject")) }
    }.getOrDefault(emptyList())

    suspend fun students(token: String): List<Student> = runCatching {
        val array = JSONArray(client.select("students", token, "select=id,full_name,class_id&order=created_at.desc").getOrThrow())
        List(array.length()) { val item = array.getJSONObject(it); Student(item.optString("id").stableId(), item.optString("full_name"), item.optString("class_id")) }
    }.getOrDefault(emptyList())

    suspend fun exams(token: String): List<Exam> = runCatching {
        val array = JSONArray(client.select("exams", token, "select=id,title,subject&order=created_at.desc").getOrThrow())
        List(array.length()) { val item = array.getJSONObject(it); Exam(item.optString("id").stableId(), item.optString("title"), item.optString("subject")) }
    }.getOrDefault(emptyList())

    suspend fun notices(token: String): List<Notice> = runCatching {
        val array = JSONArray(client.select("notices", token, "select=id,title,body&order=created_at.desc").getOrThrow())
        List(array.length()) { val item = array.getJSONObject(it); Notice(item.optString("id").stableId(), item.optString("title"), item.optString("body")) }
    }.getOrDefault(emptyList())

    suspend fun addClass(token: String, teacherId: String, name: String, subject: String): Boolean =
        client.insert("classes", token, JSONObject().put("teacher_id", teacherId).put("name", name).put("subject", subject).toString()).isSuccess

    suspend fun addStudent(token: String, name: String, className: String): Boolean {
        val classId = findId(token, "classes", "name", className) ?: return false
        return client.insert("students", token, JSONObject().put("class_id", classId).put("full_name", name).toString()).isSuccess
    }

    suspend fun addExam(token: String, title: String, subject: String, className: String): Boolean {
        val classId = findId(token, "classes", "name", className) ?: return false
        return client.insert("exams", token, JSONObject().put("class_id", classId).put("title", title).put("subject", subject).toString()).isSuccess
    }

    suspend fun addQuestion(token: String, examTitle: String, text: String, answer: String, options: List<String>): Boolean {
        val examId = findId(token, "exams", "title", examTitle) ?: return false
        return client.insert("questions", token, JSONObject().put("exam_id", examId).put("question_text", text).put("correct_answer", answer).put("options", JSONArray(options)).toString()).isSuccess
    }

    suspend fun addNotice(token: String, authorId: String, title: String, body: String): Boolean =
        client.insert("notices", token, JSONObject().put("author_id", authorId).put("title", title).put("body", body).toString()).isSuccess

    suspend fun addGrade(token: String, studentName: String, subject: String, score: Int, total: Int): Boolean {
        val studentId = findId(token, "students", "full_name", studentName) ?: return false
        return client.insert("grades", token, JSONObject().put("student_id", studentId).put("subject", subject).put("score", score).put("total", total).toString()).isSuccess
    }

    suspend fun addAttendance(token: String, studentName: String, className: String, date: String, present: Boolean): Boolean {
        val studentId = findId(token, "students", "full_name", studentName) ?: return false
        val classId = findId(token, "classes", "name", className) ?: return false
        return client.insert("attendance", token, JSONObject().put("student_id", studentId).put("class_id", classId).put("attendance_date", date).put("present", present).toString()).isSuccess
    }

    private suspend fun findId(token: String, table: String, column: String, value: String): String? {
        val encoded = value.replace(" ", "%20")
        val response = client.select(table, token, "select=id&$column=eq.$encoded&limit=1").getOrNull() ?: return null
        val array = runCatching { JSONArray(response) }.getOrNull() ?: return null
        return array.optJSONObject(0)?.optString("id")?.ifBlank { null }
    }

    private fun String.stableId(): Long = kotlin.math.abs(hashCode().toLong()).coerceAtLeast(1L)
}
