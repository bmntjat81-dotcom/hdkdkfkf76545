package com.alfnon.platform.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class LocalEducationStore(context: Context) {
    private val prefs = context.getSharedPreferences("alf_non_education", Context.MODE_PRIVATE)

    fun classes(): List<ClassRoom> = read("classes").map { ClassRoom(it.optLong("id"), it.optString("name"), it.optString("subject"), it.optInt("students")) }
    fun students(): List<Student> = read("students").map { Student(it.optLong("id"), it.optString("name"), it.optString("className"), it.optString("average")) }
    fun exams(): List<Exam> = read("exams").map { Exam(it.optLong("id"), it.optString("title"), it.optString("subject"), it.optInt("questions")) }
    fun grades(): List<GradeRecord> = read("grades").map { GradeRecord(it.optLong("id"), it.optString("student"), it.optString("subject"), it.optInt("score"), it.optInt("total")) }
    fun questions(): List<Question> = read("questions").map { q -> Question(q.optLong("id"), q.optString("exam"), q.optString("text"), q.optString("answer"), q.optJSONArray("options")?.let { a -> List(a.length()) { a.optString(it) } } ?: emptyList()) }
    fun attempts(): List<ExamAttempt> = read("attempts").map { ExamAttempt(it.optLong("id"), it.optString("student"), it.optString("exam"), it.optInt("score"), it.optInt("total")) }
    fun attendance(): List<AttendanceRecord> = read("attendance").map { AttendanceRecord(it.optLong("id"), it.optString("student"), it.optString("className"), it.optString("date"), it.optBoolean("present")) }
    fun notices(): List<Notice> = read("notices").map { Notice(it.optLong("id"), it.optString("title"), it.optString("body")) }

    fun addClass(name: String, subject: String) { write("classes", classes().map { it.toJson() } + ClassRoom(System.currentTimeMillis(), name, subject).toJson()) }
    fun addStudent(name: String, className: String) { write("students", students().map { it.toJson() } + Student(System.currentTimeMillis(), name, className).toJson()) }
    fun addExam(title: String, subject: String) { write("exams", exams().map { it.toJson() } + Exam(System.currentTimeMillis(), title, subject).toJson()) }
    fun addGrade(student: String, subject: String, score: Int, total: Int) { write("grades", grades().map { it.toJson() } + GradeRecord(System.currentTimeMillis(), student, subject, score, total).toJson()) }
    fun addQuestion(exam: String, text: String, answer: String, options: List<String>) { write("questions", questions().map { it.toJson() } + Question(System.currentTimeMillis(), exam, text, answer, options).toJson()) }
    fun addAttempt(student: String, exam: String, score: Int, total: Int) { write("attempts", attempts().map { it.toJson() } + ExamAttempt(System.currentTimeMillis(), student, exam, score, total).toJson()) }
    fun addAttendance(student: String, className: String, date: String, present: Boolean) { write("attendance", attendance().map { it.toJson() } + AttendanceRecord(System.currentTimeMillis(), student, className, date, present).toJson()) }
    fun addNotice(title: String, body: String) { write("notices", notices().map { it.toJson() } + Notice(System.currentTimeMillis(), title, body).toJson()) }

    fun replaceClasses(values: List<ClassRoom>) { write("classes", values.map { it.toJson() }) }
    fun replaceStudents(values: List<Student>) { write("students", values.map { it.toJson() }) }
    fun replaceExams(values: List<Exam>) { write("exams", values.map { it.toJson() }) }
    fun replaceNotices(values: List<Notice>) { write("notices", values.map { it.toJson() }) }

    private fun read(key: String): List<JSONObject> = runCatching {
        val array = JSONArray(prefs.getString(key, "[]")); List(array.length()) { array.getJSONObject(it) }
    }.getOrDefault(emptyList())
    private fun write(key: String, values: List<JSONObject>) { prefs.edit().putString(key, JSONArray(values).toString()).apply() }
    private fun ClassRoom.toJson() = JSONObject().put("id", id).put("name", name).put("subject", subject).put("students", students)
    private fun Student.toJson() = JSONObject().put("id", id).put("name", name).put("className", className).put("average", average)
    private fun Exam.toJson() = JSONObject().put("id", id).put("title", title).put("subject", subject).put("questions", questions)
    private fun GradeRecord.toJson() = JSONObject().put("id", id).put("student", student).put("subject", subject).put("score", score).put("total", total)
    private fun Question.toJson() = JSONObject().put("id", id).put("exam", exam).put("text", text).put("answer", answer).put("options", JSONArray(options))
    private fun ExamAttempt.toJson() = JSONObject().put("id", id).put("student", student).put("exam", exam).put("score", score).put("total", total)
    private fun AttendanceRecord.toJson() = JSONObject().put("id", id).put("student", student).put("className", className).put("date", date).put("present", present)
    private fun Notice.toJson() = JSONObject().put("id", id).put("title", title).put("body", body)
}
