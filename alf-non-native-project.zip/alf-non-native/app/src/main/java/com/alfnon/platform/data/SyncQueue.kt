package com.alfnon.platform.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "sync_queue", indices = [Index(value = ["createdAt"])])
data class SyncQueueEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entity: String,
    val entityId: Long,
    val action: String,
    val payload: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface SyncQueueDao {
    @Query("SELECT * FROM sync_queue ORDER BY createdAt ASC") fun observePending(): Flow<List<SyncQueueEntity>>
    @Insert suspend fun enqueue(item: SyncQueueEntity): Long
    @Query("DELETE FROM sync_queue WHERE id = :id") suspend fun remove(id: Long)
    @Query("DELETE FROM sync_queue") suspend fun clear()
}
