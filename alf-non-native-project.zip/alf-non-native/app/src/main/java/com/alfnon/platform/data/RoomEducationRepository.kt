package com.alfnon.platform.data

import kotlinx.coroutines.flow.Flow

class RoomEducationRepository(private val dao: EducationDao) {
    fun classes(): Flow<List<ClassEntity>> = dao.observeClasses()
    fun students(classId: Long): Flow<List<StudentEntity>> = dao.observeStudents(classId)
    fun exams(classId: Long): Flow<List<ExamEntity>> = dao.observeExams(classId)
    fun questions(examId: Long): Flow<List<QuestionEntity>> = dao.observeQuestions(examId)
    fun grades(studentId: Long): Flow<List<GradeEntity>> = dao.observeGrades(studentId)
    fun attendance(studentId: Long): Flow<List<AttendanceEntity>> = dao.observeAttendance(studentId)
    fun notices(): Flow<List<NoticeEntity>> = dao.observeNotices()
    suspend fun addClass(name: String, subject: String) = dao.insertClass(ClassEntity(name = name, subject = subject))
    suspend fun addStudent(name: String, classId: Long) = dao.insertStudent(StudentEntity(name = name, classId = classId))
    suspend fun addExam(title: String, subject: String, classId: Long) = dao.insertExam(ExamEntity(title = title, subject = subject, classId = classId))
    suspend fun addQuestion(examId: Long, text: String, answer: String, options: String) = dao.insertQuestion(QuestionEntity(examId = examId, text = text, answer = answer, options = options))
    suspend fun addGrade(studentId: Long, subject: String, score: Int, total: Int) = dao.insertGrade(GradeEntity(studentId = studentId, subject = subject, score = score, total = total))
    suspend fun addAttendance(studentId: Long, date: String, present: Boolean) = dao.insertAttendance(AttendanceEntity(studentId = studentId, date = date, present = present))
    suspend fun addNotice(title: String, body: String, audience: String) = dao.insertNotice(NoticeEntity(title = title, body = body, audience = audience))
}

class SyncRepository(private val dao: SyncQueueDao) {
    fun pending(): Flow<List<SyncQueueEntity>> = dao.observePending()
    suspend fun enqueue(entity: String, entityId: Long, action: String, payload: String) = dao.enqueue(SyncQueueEntity(entity = entity, entityId = entityId, action = action, payload = payload))
    suspend fun markUploaded(id: Long) = dao.remove(id)
}
