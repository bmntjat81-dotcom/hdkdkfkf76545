package com.alfnon.platform.data

import kotlinx.coroutines.flow.first

class SyncCoordinator(
    private val queue: SyncRepository,
    private val remote: CloudDataSource = DisabledCloudDataSource()
) {
    suspend fun syncOnce(): SyncResult {
        var uploaded = 0
        var failed = 0
        queue.pending().first().forEach { operation ->
            if (remote.upload(operation)) { queue.markUploaded(operation.id); uploaded++ } else failed++
        }
        return SyncResult(uploaded, failed)
    }
}

data class SyncResult(val uploaded: Int, val failed: Int)
