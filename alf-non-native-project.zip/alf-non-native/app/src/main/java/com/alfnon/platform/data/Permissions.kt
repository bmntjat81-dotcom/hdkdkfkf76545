package com.alfnon.platform.data

object Permissions {
    fun modules(role: UserRole): Set<Module> = when (role) {
        UserRole.TEACHER -> setOf(Module.CLASSES, Module.STUDENTS, Module.EXAMS, Module.QUESTIONS, Module.GRADES, Module.ATTENDANCE, Module.REPORTS, Module.NOTICES)
        UserRole.STUDENT -> setOf(Module.EXAMS, Module.QUESTIONS, Module.ATTEMPTS, Module.GRADES, Module.NOTICES)
        UserRole.PARENT -> setOf(Module.GRADES, Module.ATTEMPTS, Module.ATTENDANCE, Module.REPORTS, Module.NOTICES)
        UserRole.ADMIN -> Module.entries.toSet()
    }
    fun can(role: UserRole, module: Module): Boolean = module in modules(role)
}
