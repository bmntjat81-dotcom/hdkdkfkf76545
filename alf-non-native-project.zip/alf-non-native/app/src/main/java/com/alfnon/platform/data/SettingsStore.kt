package com.alfnon.platform.data

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("alf_non_settings", Context.MODE_PRIVATE)
    fun darkMode(): Boolean = prefs.getBoolean("dark_mode", true)
    fun setDarkMode(value: Boolean) { prefs.edit().putBoolean("dark_mode", value).apply() }
}
