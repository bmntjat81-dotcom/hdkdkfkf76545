# منصة ألف ونون Native

اسم التطبيق: **منصة ألف ونون**

اسم الحزمة: `com.alfnon.platform`

## الحالة الحالية

تم إنشاء مشروع Supabase جديد باسم «منصة ألف ونون» في منطقة `ap-southeast-1`، وحالته `ACTIVE_HEALTHY`. تم تطبيق مخطط قاعدة البيانات بنجاح مع تفعيل RLS وسياسات الأدوار.

الجداول السحابية الحالية هي: profiles، classes، students، exams، questions، exam_attempts، grades، attendance، notices.

تم ربط تسجيل الدخول بجسر Supabase Auth، وتم ربط عمليات الإضافة والمزامنة العكسية الأساسية. كما تمت إضافة عميل Supabase Storage لرفع ملفات الملازم من Uri Android إلى مجلد materials عند تفعيل الـ bucket.

تمت إضافة Gradle Wrapper 8.9 إلى المشروع لتسهيل البناء على أي جهاز Android متوافق.

## المكونات

- Kotlin وJetpack Compose.
- MVVM.
- Room للعمل دون اتصال.
- Supabase Auth وREST وStorage.
- RLS وصلاحيات الأدوار.
- Sync Queue وSync Coordinator.
- إشعارات Android المحلية.
- Release وR8/ProGuard.
- Gradle Wrapper.

## فحص البناء

تم تشغيل Gradle Wrapper بنجاح ووصل البناء إلى مرحلة موارد Android. تعذر إكمال APK داخل Sandbox لأن AAPT2 المضمّن هو ملف Linux x86 بينما البيئة ARM؛ لذلك يلزم تشغيل `./gradlew assembleDebug` على Cloud Computer أو جهاز Android Studio متوافق.

## المتبقي خارج البيئة الحالية

إنشاء bucket Storage من لوحة Supabase أو API الإداري، تفعيل Firebase Push Notifications، توقيع Release بمفتاح خاص، ثم بناء APK/AAB على بيئة x86_64 أو جهاز Android Studio.
