package com.alfnon.platform.data

import android.content.Context
import androidx.room.Room

object DatabaseProvider {
    @Volatile private var instance: AppDatabase? = null
    fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
        instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "alf_non_education.db").addMigrations(DatabaseMigrations.V1_TO_V2).build().also { instance = it }
    }
}
