package com.alfnon.platform.data

object Validation {
    fun name(value: String) = value.trim().length in 2..80
    fun code(value: String) = value.trim().length >= 3
    fun score(score: Int, total: Int) = total > 0 && score in 0..total
    fun nonEmpty(vararg values: String) = values.all { it.trim().isNotEmpty() }
}
