package com.alfnon.platform.data

data class GradeRecord(val id: Long, val student: String, val subject: String, val score: Int, val total: Int)
data class ReportSummary(val title: String, val value: String, val detail: String)
