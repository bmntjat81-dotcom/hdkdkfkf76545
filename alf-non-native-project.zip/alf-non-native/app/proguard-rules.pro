# Room entities and generated adapters
-keep class com.alfnon.nativeapp.data.** { *; }
# Keep Kotlin metadata used by serialization/reflection
-keep class kotlin.Metadata { *; }
-dontwarn kotlinx.coroutines.**
