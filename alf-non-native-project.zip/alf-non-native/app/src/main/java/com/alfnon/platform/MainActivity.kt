package com.alfnon.platform

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alfnon.platform.data.DashboardCard
import com.alfnon.platform.data.UserRole
import com.alfnon.platform.data.Module
import kotlinx.coroutines.delay

private val Navy = Color(0xFF0B1020)
private val Surface = Color(0xFF151C33)
private val Card = Color(0xFF1E2743)
private val Blue = Color(0xFF3B82F6)
private val Gold = Color(0xFFF59E0B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifications.initialize(this)
        setContent { AlfNonApp() }
    }
}

@Composable
private fun AlfNonApp(vm: AppViewModel = viewModel()) {
    val screen by vm.screen.collectAsState()
    val darkMode by vm.darkMode.collectAsState()
    val cloudStatus by vm.cloudStatus.collectAsState()
    CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = if (darkMode) darkColorScheme(primary = Blue, background = Navy, surface = Surface) else lightColorScheme(primary = Blue)) {
            Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
                when (val current = screen) {
                    AppScreen.Welcome -> WelcomeScreen(onStart = vm::start)
                    AppScreen.RolePicker -> RolePickerScreen(onRole = vm::chooseRole)
                    is AppScreen.Login -> LoginScreen(role = current.role, onLogin = vm::login)
                    is AppScreen.Dashboard -> DashboardScreen(role = current.role, name = current.name, darkMode = darkMode, cloudStatus = cloudStatus, onToggleTheme = vm::toggleDarkMode, onLogout = vm::logout, onModule = { vm.openModule(it, current.role, current.name) })
                    is AppScreen.ModuleScreen -> EducationModuleScreen(current, vm)
                }
            }
        }
    }
}

@Composable
private fun WelcomeScreen(onStart: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(122.dp).background(Blue, RoundedCornerShape(32.dp)), contentAlignment = Alignment.Center) { Text("أن", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Black) }
        Spacer(Modifier.height(24.dp))
        Text("ألف ونون", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black)
        Text("منصة المعلم الذكية", color = Gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(42.dp))
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) { Text("ابدأ الآن", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun RolePickerScreen(onRole: (UserRole) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(28.dp))
        Text("اختر نوع الحساب", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("سنجهّز لك لوحة التحكم المناسبة", color = Color.LightGray, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp, bottom = 24.dp))
        UserRole.entries.forEach { role ->
            Card(onClick = { onRole(role) }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(role.icon, fontSize = 34.sp); Spacer(Modifier.width(16.dp))
                    Column { Text(role.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black); Text(role.subtitle, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) }
                }
            }
        }
    }
}

@Composable
private fun LoginScreen(role: UserRole, onLogin: (UserRole, String, String) -> Boolean) {
    var name by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(role.icon, fontSize = 56.sp)
        Text("دخول ${role.title}", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 12.dp))
        Text("أدخل بياناتك للمتابعة", color = Color.LightGray, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp, bottom = 26.dp))
        OutlinedTextField(value = name, onValueChange = { name = it; error = false }, label = { Text("الاسم") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = code, onValueChange = { code = it; error = false }, label = { Text("رمز الدخول") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
        if (error) Text("أدخل اسمًا ورمزًا صحيحين للمتابعة", color = Color(0xFFFF7777), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(22.dp))
        Button(onClick = { error = !onLogin(role, name, code) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) { Text("دخول", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        Text("يتم حفظ الحساب محليًا وربطه بالسحابة عند توفر الإنترنت", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 18.dp))
    }
}

@Composable
private fun DashboardScreen(role: UserRole, name: String, darkMode: Boolean, cloudStatus: String, onToggleTheme: () -> Unit, onLogout: () -> Unit, onModule: (Module) -> Unit) {
    val cards = when (role) {
        UserRole.TEACHER -> listOf(DashboardCard("الصفوف", "0", "📚"), DashboardCard("الطلاب", "0", "👥"), DashboardCard("الاختبارات", "0", "📝"), DashboardCard("الدرجات", "0", "📊"))
        UserRole.STUDENT -> listOf(DashboardCard("نقاطي", "50", "⭐"), DashboardCard("الاختبارات", "0", "📝"), DashboardCard("إنجازي", "0%", "🏆"), DashboardCard("المواد", "0", "📚"))
        UserRole.PARENT -> listOf(DashboardCard("الأبناء", "0", "👨‍👩‍👧"), DashboardCard("متوسط الدرجات", "—", "📊"), DashboardCard("التنبيهات", "0", "🔔"), DashboardCard("الحضور", "—", "📅"))
        UserRole.ADMIN -> listOf(DashboardCard("المستخدمون", "0", "👥"), DashboardCard("الأكواد", "0", "🔑"), DashboardCard("الإشعارات", "0", "🔔"), DashboardCard("التقارير", "0", "📊"))
    }
    Scaffold(containerColor = Navy, topBar = { TopAppBar(title = { Text("ألف ونون · ${role.title}", fontWeight = FontWeight.Black) }, actions = { TextButton(onClick = onToggleTheme) { Text(if (darkMode) "فاتح" else "داكن", color = Gold) }; TextButton(onClick = onLogout) { Text("خروج", color = Gold) } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Surface, titleContentColor = Color.White)) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("مرحبًا، $name", color = Color.LightGray, fontSize = 14.sp)
            Text("حالة الاتصال: $cloudStatus", color = if (cloudStatus == "متصل سحابيًا") Color(0xFF5EE68A) else Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
            Text("لوحة التحكم الرئيسية", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
            LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(cards) { card ->
                    val module = when (card.title) { "الصفوف" -> Module.CLASSES; "الطلاب" -> Module.STUDENTS; "الاختبارات" -> Module.EXAMS; "الدرجات", "متوسط الدرجات" -> Module.GRADES; "الحضور" -> Module.ATTENDANCE; "التقارير" -> Module.REPORTS; "الإشعارات" -> Module.NOTICES; else -> null }
                    Card(onClick = { module?.let(onModule) }, colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp).fillMaxWidth()) { Text(card.icon, fontSize = 30.sp); Text(card.title, color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp)); Text(card.value, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 5.dp)) } }
                }
            }
            Spacer(Modifier.height(22.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) { Text("المزامنة السحابية", color = Gold, fontWeight = FontWeight.Bold); Text("تُحفظ البيانات محليًا أولًا، ثم تُرسل إلى Supabase عند توفر الاتصال، مع تطبيق صلاحيات الدور على الخادم.", color = Color.LightGray, fontSize = 13.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 8.dp)) } }
        }
    }
}

@Composable
private fun EducationModuleScreen(current: AppScreen.ModuleScreen, vm: AppViewModel) {
    val revision by vm.revision.collectAsState()
    var first by rememberSaveable { mutableStateOf("") }
    var second by rememberSaveable { mutableStateOf("") }
    var score by rememberSaveable { mutableStateOf("") }
    var total by rememberSaveable { mutableStateOf("") }
    var third by rememberSaveable { mutableStateOf("") }
    var fourth by rememberSaveable { mutableStateOf("") }
    val title = current.module.title
    val entries = when (current.module) {
        Module.CLASSES -> vm.classes().map { "${it.name} · ${it.subject}" }
        Module.STUDENTS -> vm.students().map { "${it.name} · ${it.className}" }
        Module.EXAMS -> vm.exams().map { "${it.title} · ${it.subject}" }
        Module.QUESTIONS -> vm.questions().map { "${it.exam} · ${it.text} · الإجابة: ${it.answer}" }
        Module.GRADES -> vm.grades().map { "${it.student} · ${it.subject}: ${it.score}/${it.total} (${(it.score * 100) / it.total}%)" }
        Module.ATTEMPTS -> vm.attempts().map { "${it.student} · ${it.exam}: ${it.score}/${it.total}" }
        Module.ATTENDANCE -> vm.attendance().map { "${it.student} · ${it.className} · ${it.date}: ${if (it.present) "حاضر" else "غائب"}" }
        Module.REPORTS -> vm.students().map { val r = vm.reportFor(it.name); "${r.student}: متوسط ${r.average}% · اختبارات ${r.exams} · حضور ${r.attendance}%" }
        Module.NOTICES -> vm.notices().map { "${it.title} · ${it.body}" }
    }
    if (current.role == UserRole.STUDENT && current.module == Module.QUESTIONS) {
        StudentExamRunnerScreen(current.name, vm.questions(), vm)
        return
    }
    Scaffold(containerColor = Navy, topBar = { TopAppBar(title = { Text("$title · ${current.role.title}", fontWeight = FontWeight.Black) }, navigationIcon = { TextButton(onClick = { vm.backToDashboard(current.role, current.name) }) { Text("رجوع", color = Gold) } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Surface, titleContentColor = Color.White)) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("إدارة $title", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("بيانات محلية قابلة للمزامنة السحابية لاحقًا", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 16.dp))
            OutlinedTextField(value = first, onValueChange = { first = it }, label = { Text(if (current.module == Module.CLASSES) "اسم الصف" else if (current.module == Module.STUDENTS) "اسم الطالب" else if (current.module == Module.EXAMS) "اسم الاختبار" else if (current.module == Module.GRADES || current.module == Module.ATTENDANCE) "اسم الطالب" else "عنوان الإشعار") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = second, onValueChange = { second = it }, label = { Text(if (current.module == Module.NOTICES) "نص الإشعار" else if (current.module == Module.GRADES) "المادة" else if (current.module == Module.ATTENDANCE) "اسم الصف" else "المادة أو الصف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            if (current.module == Module.GRADES) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(value = score, onValueChange = { score = it }, label = { Text("الدرجة") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = total, onValueChange = { total = it }, label = { Text("من") }, singleLine = true, modifier = Modifier.weight(1f))
                }
            }
            if (current.module == Module.QUESTIONS) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = third, onValueChange = { third = it }, label = { Text("الإجابة الصحيحة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = fourth, onValueChange = { fourth = it }, label = { Text("الاختيارات مفصولة بعلامة | (اختياري)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            if (current.module == Module.ATTENDANCE) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = third, onValueChange = { third = it }, label = { Text("التاريخ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = fourth, onValueChange = { fourth = it }, label = { Text("حاضر أو غائب") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(10.dp))
            Button(enabled = current.module != Module.ATTEMPTS && current.module != Module.REPORTS, onClick = { when (current.module) { Module.CLASSES -> vm.addClass(first, second); Module.STUDENTS -> vm.addStudent(first, second); Module.EXAMS -> vm.addExam(first, second); Module.QUESTIONS -> vm.addQuestion(first, second, third, fourth); Module.GRADES -> vm.addGrade(first, second, score, total); Module.ATTENDANCE -> vm.addAttendance(first, second, third, fourth); Module.NOTICES -> vm.addNotice(first, second); Module.ATTEMPTS, Module.REPORTS -> Unit }; first = ""; second = ""; third = ""; fourth = ""; score = ""; total = "" }, modifier = Modifier.fillMaxWidth()) { Text("إضافة $title") }
            if (current.module == Module.EXAMS) {
                TextButton(onClick = { vm.openModule(Module.QUESTIONS, current.role, current.name) }) { Text("إدارة أسئلة الاختبارات", color = Gold) }
            }
            if (current.module == Module.QUESTIONS && current.role == UserRole.STUDENT) {
                TextButton(onClick = { vm.openModule(Module.ATTEMPTS, current.role, current.name) }) { Text("عرض محاولاتي", color = Gold) }
            }
            Spacer(Modifier.height(20.dp))
            if (entries.isEmpty()) Text("لا توجد بيانات بعد. أضف أول عنصر من النموذج أعلاه.", color = Color.Gray, modifier = Modifier.padding(top = 20.dp))
            entries.forEachIndexed { index, value -> Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text("${index + 1}", color = Gold, fontWeight = FontWeight.Black); Spacer(Modifier.width(12.dp)); Text(value, color = Color.White, fontSize = 14.sp) } } }
        }
    }
}

@Composable
private fun StudentExamRunnerScreen(student: String, questions: List<com.alfnon.platform.data.Question>, vm: AppViewModel) {
    var answer by rememberSaveable { mutableStateOf("") }
    var answerError by rememberSaveable { mutableStateOf(false) }
    var index by rememberSaveable { mutableIntStateOf(0) }
    var result by rememberSaveable { mutableStateOf<String?>(null) }
    var remainingSeconds by rememberSaveable { mutableIntStateOf(300) }
    val answers = remember { mutableStateMapOf<Int, String>() }
    val examQuestions = questions.groupBy { it.exam }.values.firstOrNull().orEmpty()
    val question = examQuestions.getOrNull(index)
    fun finishExam() {
        if (examQuestions.isNotEmpty() && result == null) {
            val score = examQuestions.indices.count { i -> examQuestions[i].answer.trim().equals(answers[i]?.trim().orEmpty(), true) }
            vm.recordAttempt(student, examQuestions.first().exam, score, examQuestions.size)
            result = "نتيجتك: $score من ${examQuestions.size} (${(score * 100) / examQuestions.size}%)"
        }
    }
    LaunchedEffect(result) {
        while (remainingSeconds > 0 && result == null) { delay(1000); remainingSeconds-- }
        if (remainingSeconds == 0) finishExam()
    }
    Scaffold(containerColor = Navy, topBar = { TopAppBar(title = { Text("اختبار الطالب", fontWeight = FontWeight.Black) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Surface, titleContentColor = Color.White)) }) { padding ->
        Column(Modifier.padding(padding).padding(18.dp)) {
            if (question == null && result == null) {
                Text("لا يوجد اختبار متاح حاليًا", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            } else if (result != null) {
                Text("تم إنهاء الاختبار", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text(result!!, color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(top = 18.dp))
            } else {
                Text("${question!!.exam} · السؤال ${index + 1} من ${examQuestions.size} · الوقت ${remainingSeconds / 60}:${(remainingSeconds % 60).toString().padStart(2, '0')}", color = Gold, fontWeight = FontWeight.Bold)
                Text(question.text, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 18.dp, bottom = 18.dp))
                if (question.options.isNotEmpty()) {
                    question.options.forEach { option ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                            RadioButton(selected = answer == option, onClick = { answer = option; answerError = false })
                            Text(option, color = Color.White, modifier = Modifier.padding(start = 6.dp))
                        }
                    }
                } else OutlinedTextField(value = answer, onValueChange = { answer = it; answerError = false }, label = { Text("إجابتك") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                if (answerError) Text("يجب إدخال إجابة قبل الانتقال", color = Color(0xFFFF7777), fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                Button(onClick = {
                    if (answer.isBlank()) answerError = true
                    else { answers[index] = answer; if (index < examQuestions.lastIndex) { index++; answer = "" } else finishExam() }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (index < examQuestions.lastIndex) "السؤال التالي" else "تسليم الاختبار") }
            }
        }
    }
}
