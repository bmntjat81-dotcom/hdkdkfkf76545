package com.alfnon.platform.data

import android.content.Context

class LocalSession(context: Context) {
    private val prefs = context.getSharedPreferences("alf_non_session", Context.MODE_PRIVATE)

    fun save(name: String, role: UserRole) {
        prefs.edit().putString("name", name).putString("role", role.name).apply()
    }

    fun name(): String? = prefs.getString("name", null)
    fun role(): UserRole? = prefs.getString("role", null)?.let { runCatching { UserRole.valueOf(it) }.getOrNull() }
    fun clear() = prefs.edit().clear().apply()
}
