package com.alfnon.platform.data

import android.content.Context
import org.json.JSONObject

class SupabaseAuthBridge(context: Context) {
    private val client = SupabaseRestClient()
    private val prefs = context.getSharedPreferences("alf_non_supabase_session", Context.MODE_PRIVATE)

    suspend fun ensureAccount(name: String, code: String, role: UserRole): Boolean {
        val email = syntheticEmail(name)
        val signIn = client.signIn(email, code)
        val body = signIn.getOrElse {
            client.signUp(email, code).getOrNull() ?: return false
        }
        val json = runCatching { JSONObject(body) }.getOrNull()
        val token = json?.optString("access_token").orEmpty()
        if (token.isNotBlank()) {
            prefs.edit().putString("access_token", token).putString("role", role.name).apply()
            val userId = json?.optJSONObject("user")?.optString("id").orEmpty()
            if (userId.isNotBlank()) {
                prefs.edit().putString("user_id", userId).apply()
                client.insert("profiles", token, JSONObject().apply { put("id", userId); put("full_name", name); put("role", role.name.lowercase()) })
            }
        }
        return true
    }

    fun accessToken(): String? = prefs.getString("access_token", null)
    fun userId(): String? = prefs.getString("user_id", null)
    fun clear() { prefs.edit().clear().apply() }

    private fun syntheticEmail(name: String): String = normalize(name) + "@users.alfnon.app"
    private fun normalize(value: String): String = value.trim().lowercase().replace(Regex("[^a-z0-9_]+"), "_").take(40).ifBlank { "user" }
}
