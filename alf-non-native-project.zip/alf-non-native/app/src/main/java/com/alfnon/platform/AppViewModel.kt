package com.alfnon.platform

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alfnon.platform.data.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface AppScreen {
    data object Welcome : AppScreen
    data object RolePicker : AppScreen
    data class Login(val role: UserRole) : AppScreen
    data class Dashboard(val role: UserRole, val name: String) : AppScreen
    data class ModuleScreen(val role: UserRole, val name: String, val module: Module) : AppScreen
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val session = LocalSession(app)
    private val auth = LocalAuthStore(app)
    private val settings = SettingsStore(app)
    private val cloudAuth = SupabaseAuthBridge(app)
    private val cloudEducation = SupabaseEducationRepository()
    private val store = LocalEducationStore(app)
    private val _screen = MutableStateFlow<AppScreen>(initialScreen())
    val screen: StateFlow<AppScreen> = _screen.asStateFlow()
    private val _revision = MutableStateFlow(0)
    val revision: StateFlow<Int> = _revision.asStateFlow()
    private val _darkMode = MutableStateFlow(settings.darkMode())
    val darkMode: StateFlow<Boolean> = _darkMode.asStateFlow()
    private val _cloudStatus = MutableStateFlow("محلي")
    val cloudStatus: StateFlow<String> = _cloudStatus.asStateFlow()

    private fun initialScreen(): AppScreen = session.role()?.let { AppScreen.Dashboard(it, session.name() ?: "مستخدم") } ?: AppScreen.Welcome
    fun start() { _screen.value = AppScreen.RolePicker }
    fun chooseRole(role: UserRole) { _screen.value = AppScreen.Login(role) }
    fun login(role: UserRole, name: String, code: String): Boolean {
        val cleanName = name.trim()
        if (!auth.authenticate(cleanName, code.trim(), role)) return false
        session.save(cleanName, role); _screen.value = AppScreen.Dashboard(role, cleanName)
        _cloudStatus.value = "جارٍ ربط الحساب"
        viewModelScope.launch {
            if (cloudAuth.ensureAccount(cleanName, code.trim(), role)) { syncDown(); _cloudStatus.value = "متصل سحابيًا" } else _cloudStatus.value = "محلي دون اتصال"
        }
        return true
    }
    fun openModule(module: Module, role: UserRole, name: String) { if (Permissions.can(role, module)) _screen.value = AppScreen.ModuleScreen(role, name, module) }
    fun backToDashboard(role: UserRole, name: String) { _screen.value = AppScreen.Dashboard(role, name) }
    fun classes() = store.classes()
    fun students() = store.students()
    fun exams() = store.exams()
    fun grades() = store.grades()
    fun questions() = store.questions()
    fun attempts() = store.attempts()
    fun attendance() = store.attendance()
    fun reportFor(student: String): ProgressReport {
        val gs = store.grades().filter { it.student.equals(student, true) }
        val ats = store.attempts().filter { it.student.equals(student, true) }
        val at = store.attendance().filter { it.student.equals(student, true) }
        val avg = if (gs.isEmpty()) 0 else gs.map { (it.score * 100) / it.total.coerceAtLeast(1) }.average().toInt()
        val presence = if (at.isEmpty()) 0 else at.count { it.present } * 100 / at.size
        return ProgressReport(student, ats.size, avg, presence)
    }
    fun notices() = store.notices()
    fun addClass(name: String, subject: String) { if (name.isNotBlank() && subject.isNotBlank()) { val n = name.trim(); val s = subject.trim(); store.addClass(n, s); _revision.value++; viewModelScope.launch { val token = cloudAuth.accessToken(); val userId = cloudAuth.userId(); if (token != null && userId != null) cloudEducation.addClass(token, userId, n, s) } } }
    fun addStudent(name: String, className: String) { if (name.isNotBlank() && className.isNotBlank()) { val n = name.trim(); val c = className.trim(); store.addStudent(n, c); _revision.value++; viewModelScope.launch { cloudAuth.accessToken()?.let { cloudEducation.addStudent(it, n, c) } } } }
    fun addExam(title: String, subject: String) { if (title.isNotBlank() && subject.isNotBlank()) { store.addExam(title.trim(), subject.trim()); _revision.value++ } }
    fun addGrade(student: String, subject: String, scoreText: String, totalText: String): Boolean {
        val score = scoreText.toIntOrNull(); val total = totalText.toIntOrNull()
        if (student.isBlank() || subject.isBlank() || score == null || total == null || total <= 0 || score < 0 || score > total) return false
        val studentName = student.trim(); val subjectName = subject.trim()
        store.addGrade(studentName, subjectName, score, total); _revision.value++
        viewModelScope.launch { cloudAuth.accessToken()?.let { cloudEducation.addGrade(it, studentName, subjectName, score, total) } }
        return true
    }
    fun addQuestion(exam: String, text: String, answer: String, optionsText: String) {
        val options = optionsText.split("|").map { it.trim() }.filter { it.isNotBlank() }
        if (exam.isNotBlank() && text.isNotBlank() && answer.isNotBlank() && (options.isEmpty() || options.contains(answer.trim()))) { val e = exam.trim(); val t = text.trim(); val a = answer.trim(); store.addQuestion(e, t, a, options); _revision.value++; viewModelScope.launch { cloudAuth.accessToken()?.let { cloudEducation.addQuestion(it, e, t, a, options) } } }
    }
    fun submitAttempt(student: String, exam: String, answer: String): Boolean {
        val qs = store.questions().filter { it.exam.equals(exam, true) }
        if (qs.isEmpty()) return false
        val score = qs.count { it.answer.trim().equals(answer.trim(), true) }
        store.addAttempt(student, exam, score, qs.size); _revision.value++; return true
    }
    fun recordAttempt(student: String, exam: String, score: Int, total: Int) {
        if (student.isNotBlank() && exam.isNotBlank() && total > 0) { store.addAttempt(student, exam, score.coerceIn(0, total), total); _revision.value++ }
    }
    fun addAttendance(student: String, className: String, date: String, presentText: String) {
        if (student.isNotBlank() && className.isNotBlank() && date.isNotBlank()) { val studentName = student.trim(); val classNameValue = className.trim(); val dateValue = date.trim(); val present = presentText.trim().equals("حاضر", true); store.addAttendance(studentName, classNameValue, dateValue, present); _revision.value++; viewModelScope.launch { cloudAuth.accessToken()?.let { cloudEducation.addAttendance(it, studentName, classNameValue, dateValue, present) } } }
    }
    fun addNotice(title: String, body: String) { if (title.isNotBlank() && body.isNotBlank()) { val t = title.trim(); val b = body.trim(); store.addNotice(t, b); _revision.value++; viewModelScope.launch { val token = cloudAuth.accessToken(); val userId = cloudAuth.userId(); if (token != null && userId != null) cloudEducation.addNotice(token, userId, t, b) } } }
    fun logout() { session.clear(); cloudAuth.clear(); _cloudStatus.value = "محلي"; _screen.value = AppScreen.RolePicker }
    fun toggleDarkMode() { val next = !_darkMode.value; settings.setDarkMode(next); _darkMode.value = next }

    private suspend fun syncDown() {
        val token = cloudAuth.accessToken() ?: return
        val remoteClasses = cloudEducation.classes(token)
        val remoteStudents = cloudEducation.students(token)
        val remoteExams = cloudEducation.exams(token)
        val remoteNotices = cloudEducation.notices(token)
        if (remoteClasses.isNotEmpty()) store.replaceClasses(remoteClasses)
        if (remoteStudents.isNotEmpty()) store.replaceStudents(remoteStudents)
        if (remoteExams.isNotEmpty()) store.replaceExams(remoteExams)
        if (remoteNotices.isNotEmpty()) store.replaceNotices(remoteNotices)
        _revision.value++
    }
}
