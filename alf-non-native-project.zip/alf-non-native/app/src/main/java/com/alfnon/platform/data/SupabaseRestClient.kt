package com.alfnon.platform.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class SupabaseRestClient(
    private val baseUrl: String = SupabaseConfig.URL,
    private val publishableKey: String = SupabaseConfig.PUBLISHABLE_KEY
) {
    suspend fun signIn(email: String, password: String): Result<String> = request("/auth/v1/token?grant_type=password", "POST", JSONObject().apply {
        put("email", email); put("password", password)
    }.toString())

    suspend fun signUp(email: String, password: String): Result<String> = request("/auth/v1/signup", "POST", JSONObject().apply {
        put("email", email); put("password", password)
    }.toString())

    suspend fun select(table: String, accessToken: String, query: String = "select=*"): Result<String> = request("/rest/v1/$table?$query", "GET", null, accessToken)

    suspend fun insert(table: String, accessToken: String, body: String): Result<String> = request("/rest/v1/$table", "POST", body, accessToken)

    private suspend fun request(path: String, method: String, body: String?, accessToken: String? = null): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val connection = (URL(baseUrl + path).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 15_000
                readTimeout = 15_000
                setRequestProperty("apikey", publishableKey)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Prefer", "return=representation")
                if (!accessToken.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $accessToken")
                if (body != null) doOutput = true
            }
            body?.let { connection.outputStream.use { stream -> stream.write(it.toByteArray()) } }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            connection.disconnect()
            if (code !in 200..299) error("Supabase HTTP $code: $response")
            response
        }
    }
}
