package com.alfnon.platform.data

object SupabaseConfig {
    const val URL = "https://tjwgevxaojunsumnbrji.supabase.co"
    // Publishable/anon key: safe for client-side use when RLS policies are enabled.
    const val PUBLISHABLE_KEY = "sb_publishable_88Pjemq6AM3JoBBBF7GxNw_aRbLR7pb"
    const val PROJECT_REF = "tjwgevxaojunsumnbrji"
}
