package com.alfnon.platform.data

enum class UserRole(val title: String, val subtitle: String, val icon: String) {
    TEACHER("المعلم", "إدارة الصفوف والاختبارات والدرجات", "👨‍🏫"),
    STUDENT("الطالب", "التعلم والاختبارات والجوائز", "🎓"),
    PARENT("ولي الأمر", "متابعة مستوى الأبناء", "👨‍👩‍👧"),
    ADMIN("الإدارة", "إدارة المنصة والأكواد", "🛡️")
}

data class DashboardCard(val title: String, val value: String, val icon: String)
