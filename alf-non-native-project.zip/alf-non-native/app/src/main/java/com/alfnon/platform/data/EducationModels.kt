package com.alfnon.platform.data

data class ClassRoom(val id: Long, val name: String, val subject: String, val students: Int = 0)
data class Student(val id: Long, val name: String, val className: String, val average: String = "—")
data class Exam(val id: Long, val title: String, val subject: String, val questions: Int = 0)
data class Notice(val id: Long, val title: String, val body: String)

enum class Module(val title: String, val icon: String) {
    CLASSES("الصفوف", "📚"), STUDENTS("الطلاب", "👥"), EXAMS("الاختبارات", "📝"), QUESTIONS("الأسئلة", "❓"), GRADES("الدرجات", "📊"), ATTEMPTS("المحاولات", "✅"), ATTENDANCE("الحضور", "📅"), REPORTS("التقارير", "📈"), NOTICES("الإشعارات", "🔔")
}
