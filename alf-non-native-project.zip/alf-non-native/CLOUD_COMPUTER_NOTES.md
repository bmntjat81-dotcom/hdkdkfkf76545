# مصادر Cloud Computer الرسمية

- https://help.manus.im/en/articles/15392128-how-to-set-up-and-access-your-cloud-computer
  الخطوات: Settings > My Computer > Create Cloud Computer > اختيار الخطة والموقع والتخزين، ثم الوصول عبر Web Terminal أو SSH.
- https://help.manus.im/en/articles/15392111-what-is-the-cloud-computer
  Cloud Computer بيئة Ubuntu سحابية مستقلة ومستمرة، مختلفة عن Manus Desktop/My Computer المحلي.
- https://help.manus.im/en/articles/14320382-troubleshooting-the-my-computer-feature-not-appearing-or-connecting
  My Computer المحلي يتطلب تطبيق Manus Desktop الرسمي، وليس نسخة الويب.
