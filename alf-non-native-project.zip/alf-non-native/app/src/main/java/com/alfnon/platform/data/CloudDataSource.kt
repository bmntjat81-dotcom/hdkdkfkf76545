package com.alfnon.platform.data

/** واجهة الخادم؛ يمكن تنفيذها لاحقًا عبر Supabase أو Firebase دون تغيير الواجهات. */
interface CloudDataSource {
    suspend fun upload(operation: SyncQueueEntity): Boolean
    suspend fun downloadChanges(since: Long): List<SyncQueueEntity>
}

class DisabledCloudDataSource : CloudDataSource {
    override suspend fun upload(operation: SyncQueueEntity): Boolean = false
    override suspend fun downloadChanges(since: Long): List<SyncQueueEntity> = emptyList()
}

data class CloudConfig(val baseUrl: String = "", val projectId: String = "", val enabled: Boolean = false)
