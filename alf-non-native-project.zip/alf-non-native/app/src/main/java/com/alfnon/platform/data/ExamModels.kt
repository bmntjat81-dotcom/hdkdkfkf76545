package com.alfnon.platform.data

data class Question(val id: Long, val exam: String, val text: String, val answer: String, val options: List<String> = emptyList())
data class ExamAttempt(val id: Long, val student: String, val exam: String, val score: Int, val total: Int)
