package com.alfnon.platform.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "classes")
data class ClassEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val subject: String)

@Entity(tableName = "students")
data class StudentEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val classId: Long)

@Entity(tableName = "exams")
data class ExamEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val subject: String, val classId: Long)

@Entity(tableName = "questions")
data class QuestionEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val examId: Long, val text: String, val answer: String, val options: String = "")

@Entity(tableName = "grades")
data class GradeEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val studentId: Long, val subject: String, val score: Int, val total: Int)

@Entity(tableName = "attendance")
data class AttendanceEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val studentId: Long, val date: String, val present: Boolean)

@Entity(tableName = "notices")
data class NoticeEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val body: String, val audience: String)

@Dao
interface EducationDao {
    @Query("SELECT * FROM classes ORDER BY id DESC") fun observeClasses(): Flow<List<ClassEntity>>
    @Insert suspend fun insertClass(item: ClassEntity): Long
    @Query("SELECT * FROM students WHERE classId = :classId ORDER BY name") fun observeStudents(classId: Long): Flow<List<StudentEntity>>
    @Insert suspend fun insertStudent(item: StudentEntity): Long
    @Query("SELECT * FROM exams WHERE classId = :classId ORDER BY id DESC") fun observeExams(classId: Long): Flow<List<ExamEntity>>
    @Insert suspend fun insertExam(item: ExamEntity): Long
    @Query("SELECT * FROM questions WHERE examId = :examId ORDER BY id") fun observeQuestions(examId: Long): Flow<List<QuestionEntity>>
    @Insert suspend fun insertQuestion(item: QuestionEntity): Long
    @Query("SELECT * FROM grades WHERE studentId = :studentId ORDER BY id DESC") fun observeGrades(studentId: Long): Flow<List<GradeEntity>>
    @Insert suspend fun insertGrade(item: GradeEntity): Long
    @Query("SELECT * FROM attendance WHERE studentId = :studentId ORDER BY date DESC") fun observeAttendance(studentId: Long): Flow<List<AttendanceEntity>>
    @Insert suspend fun insertAttendance(item: AttendanceEntity): Long
    @Query("SELECT * FROM notices ORDER BY id DESC") fun observeNotices(): Flow<List<NoticeEntity>>
    @Insert suspend fun insertNotice(item: NoticeEntity): Long
}

@Database(entities = [ClassEntity::class, StudentEntity::class, ExamEntity::class, QuestionEntity::class, GradeEntity::class, AttendanceEntity::class, NoticeEntity::class, SyncQueueEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun educationDao(): EducationDao
    abstract fun syncQueueDao(): SyncQueueDao
}
