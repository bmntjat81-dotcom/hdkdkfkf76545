package com.alfnon.platform.data

data class AttendanceRecord(val id: Long, val student: String, val className: String, val date: String, val present: Boolean)
data class ProgressReport(val student: String, val exams: Int, val average: Int, val attendance: Int)
