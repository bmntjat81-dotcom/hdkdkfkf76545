package com.alfnon.platform.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class SupabaseStorageRepository(private val context: Context) {
    suspend fun upload(uri: Uri, token: String, folder: String = "materials"): String? = withContext(Dispatchers.IO) {
        runCatching {
            val name = "${folder.trim('/')}/${UUID.randomUUID()}"
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@runCatching null
            val connection = (URL("${SupabaseConfig.URL}/storage/v1/object/$name").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; doOutput = true; connectTimeout = 15_000; readTimeout = 30_000
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Content-Type", context.contentResolver.getType(uri) ?: "application/octet-stream")
                setRequestProperty("x-upsert", "true")
            }
            connection.outputStream.use { it.write(bytes) }
            if (connection.responseCode !in 200..299) return@runCatching null
            "${SupabaseConfig.URL}/storage/v1/object/public/$name"
        }.getOrNull()
    }
}
