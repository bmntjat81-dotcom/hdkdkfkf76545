package com.alfnon.platform.data

data class Attachment(val id: Long, val name: String, val uri: String, val mimeType: String, val sizeBytes: Long)

interface AttachmentRepository {
    suspend fun upload(fileUri: String, name: String, mimeType: String): Attachment?
    suspend fun delete(id: Long): Boolean
    suspend fun list(ownerId: String): List<Attachment>
}

class DisabledAttachmentRepository : AttachmentRepository {
    override suspend fun upload(fileUri: String, name: String, mimeType: String): Attachment? = null
    override suspend fun delete(id: Long): Boolean = false
    override suspend fun list(ownerId: String): List<Attachment> = emptyList()
}
